export default [
    {
        id: 1,
        slug: 'violin',
        title: 'Violin',
    },
    {
        id: 2,
        slug: 'drawing',
        title: 'Drawing',
    },
    {
        id: 3,
        slug: 'piano',
        title: 'Piano'
    },
]